#!/usr/bin/env python3
# ══════════════════════════════════════════════════════════
#  MAER Guardian — Sistema de Integridad
#  Verifica y reporta el estado de todos los archivos MAER.
#  Genera manifiestos .guardian.json, detecta cambios,
#  archivos faltantes o corrompidos, y envía reporte al log.
#
#  Uso:
#    python maer_guardian.py              → verificar todo
#    python maer_guardian.py --init       → crear manifiestos
#    python maer_guardian.py --reporte    → mostrar último reporte
#    python maer_guardian.py --watch      → modo continuo (cada hora)
#
#  Leonel Houssen Mojica — Ecatepec MX — 2026
# ══════════════════════════════════════════════════════════

import os
import sys
import json
import hashlib
import datetime
import argparse
import time
from pathlib import Path

# ── CONFIGURACIÓN ──────────────────────────────────────────
BASE_DIR = Path(__file__).parent

CARPETAS_VIGILADAS = [
    BASE_DIR / "maer_backend" / "web_ui" / "static",
    BASE_DIR / "maer_backend" / "web_ui" / "static" / "js",
    BASE_DIR / "maer_backend" / "web_ui" / "static" / "css",
    BASE_DIR / "maer_backend",
    BASE_DIR,
]

# Archivos críticos que DEBEN existir
ARCHIVOS_CRITICOS = [
    BASE_DIR / "maer_backend" / "web_ui" / "static" / "index.html",
    BASE_DIR / "maer_backend" / "web_ui" / "static" / "css" / "maer.css",
    BASE_DIR / "maer_backend" / "web_ui" / "static" / "js" / "maer.diccionario.js",
    BASE_DIR / "maer_backend" / "web_ui" / "static" / "js" / "maer.voz.js",
    BASE_DIR / "maer_backend" / "web_ui" / "static" / "js" / "maer.core.js",
    BASE_DIR / "maer_backend" / "web_ui" / "static" / "js" / "maer.chat.js",
    BASE_DIR / "maer_backend" / "web_ui" / "static" / "js" / "maer.aprendizaje.js",
    BASE_DIR / "maer_backend" / "web_ui" / "static" / "js" / "maer.archivos.js",
    BASE_DIR / "maer_backend" / "web_ui" / "static" / "js" / "maer.busqueda.js",
    BASE_DIR / "maer_backend" / "web_ui" / "static" / "js" / "maer.organizar.js",
    BASE_DIR / "maer_backend" / "web_ui" / "static" / "js" / "maer.imagenes.js",
    BASE_DIR / "maer_backend" / "web_ui" / "static" / "js" / "maer.pension.js",
    BASE_DIR / "maer_backend" / "web_ui" / "static" / "js" / "maer.tareas.js",
    BASE_DIR / "maer_backend" / "web_ui" / "static" / "js" / "maer.memoria.js",
    BASE_DIR / "maer_backend" / "web_ui" / "static" / "js" / "maer.sistema.js",
    BASE_DIR / "maer_backend" / "web_ui" / "static" / "js" / "maer.guardian.js",
    BASE_DIR / "maer_backend" / "web_ui" / "static" / "js" / "maer.ajustes.js",
    BASE_DIR / "maer_backend" / "web_ui" / "server.py",
]

LOG_FILE      = BASE_DIR / "respaldo_maer" / "guardian.log"
REPORTE_FILE  = BASE_DIR / "respaldo_maer" / "guardian_reporte.json"
MANIFEST_NAME = ".guardian.json"

COLORES = {
    "verde":    "\033[92m",
    "amarillo": "\033[93m",
    "rojo":     "\033[91m",
    "cyan":     "\033[96m",
    "gris":     "\033[90m",
    "reset":    "\033[0m",
    "bold":     "\033[1m",
}


# ── UTILIDADES ─────────────────────────────────────────────

def c(color: str, texto: str) -> str:
    """Texto con color ANSI."""
    return f"{COLORES.get(color,'')}{texto}{COLORES['reset']}"


def sha256_file(path: Path) -> str:
    """SHA-256 de un archivo."""
    h = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            for bloque in iter(lambda: f.read(65536), b""):
                h.update(bloque)
        return h.hexdigest()
    except Exception:
        return ""


def timestamp() -> str:
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def log(msg: str):
    """Escribe al log persistente."""
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    linea = f"[{timestamp()}] {msg}\n"
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(linea)


def listar_archivos_carpeta(carpeta: Path) -> list[Path]:
    """Lista archivos directamente en la carpeta (no recursivo)."""
    if not carpeta.exists():
        return []
    return [p for p in carpeta.iterdir() if p.is_file() and not p.name.startswith(".")]


# ── MANIFIESTOS ─────────────────────────────────────────────

def crear_manifiesto(carpeta: Path) -> dict:
    """Crea o actualiza el .guardian.json de una carpeta."""
    archivos = listar_archivos_carpeta(carpeta)
    entradas = {}
    for f in sorted(archivos):
        entradas[f.name] = {
            "sha256":   sha256_file(f),
            "bytes":    f.stat().st_size,
            "modificado": datetime.datetime.fromtimestamp(f.stat().st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
        }
    manifiesto = {
        "carpeta":   str(carpeta),
        "creado":    timestamp(),
        "maer_ver":  "3.1",
        "archivos":  entradas,
    }
    ruta_manifest = carpeta / MANIFEST_NAME
    with open(ruta_manifest, "w", encoding="utf-8") as f:
        json.dump(manifiesto, f, indent=2, ensure_ascii=False)
    return manifiesto


def init_manifiestos():
    """Crea manifiestos en todas las carpetas vigiladas."""
    print(c("cyan", f"\n🛡️  MAER Guardian — Inicializando manifiestos"))
    print(c("gris", f"   Hora: {timestamp()}\n"))
    for carpeta in CARPETAS_VIGILADAS:
        if not carpeta.exists():
            print(c("amarillo", f"  ⚠️  No existe: {carpeta}"))
            continue
        m = crear_manifiesto(carpeta)
        n = len(m["archivos"])
        print(c("verde", f"  ✅  {carpeta.name}/  — {n} archivos registrados"))
        log(f"INIT manifiesto: {carpeta} ({n} archivos)")
    print(c("verde", f"\n✅ Manifiestos creados. El guardián ya puede detectar cambios."))


# ── VERIFICACIÓN ─────────────────────────────────────────────

def verificar_carpeta(carpeta: Path) -> dict:
    """Verifica una carpeta contra su manifiesto."""
    resultado = {
        "carpeta": str(carpeta),
        "estado":  "ok",
        "faltantes":  [],
        "modificados": [],
        "nuevos":     [],
        "errores":    [],
    }

    ruta_manifest = carpeta / MANIFEST_NAME
    if not ruta_manifest.exists():
        resultado["estado"] = "sin_manifiesto"
        resultado["errores"].append("No hay manifiesto (.guardian.json). Ejecuta --init primero.")
        return resultado

    try:
        with open(ruta_manifest, encoding="utf-8") as f:
            manifiesto = json.load(f)
    except Exception as e:
        resultado["estado"] = "error"
        resultado["errores"].append(f"Error leyendo manifiesto: {e}")
        return resultado

    registrados = manifiesto.get("archivos", {})
    actuales    = {p.name: p for p in listar_archivos_carpeta(carpeta) if p.name != MANIFEST_NAME}

    # Archivos faltantes (estaban, ya no están)
    for nombre in registrados:
        if nombre not in actuales:
            resultado["faltantes"].append(nombre)

    # Modificados / nuevos
    for nombre, path in actuales.items():
        if nombre in registrados:
            sha_actual     = sha256_file(path)
            sha_registrado = registrados[nombre].get("sha256", "")
            if sha_actual != sha_registrado:
                resultado["modificados"].append({
                    "archivo":      nombre,
                    "sha_anterior": sha_registrado[:12] + "...",
                    "sha_actual":   sha_actual[:12] + "...",
                    "bytes_actual": path.stat().st_size,
                })
        else:
            resultado["nuevos"].append(nombre)

    if resultado["faltantes"] or resultado["modificados"]:
        resultado["estado"] = "cambios"
    elif resultado["nuevos"]:
        resultado["estado"] = "nuevos"

    return resultado


def verificar_criticos() -> list[str]:
    """Verifica que los archivos críticos existan."""
    faltantes = []
    for ruta in ARCHIVOS_CRITICOS:
        if not ruta.exists():
            faltantes.append(str(ruta.relative_to(BASE_DIR)))
    return faltantes


def verificar_todo(silencioso: bool = False) -> dict:
    """Verificación completa de todos los módulos MAER."""
    if not silencioso:
        print(c("cyan", f"\n🛡️  MAER Guardian — Verificación de Integridad"))
        print(c("gris", f"   {timestamp()}\n"))

    reporte = {
        "ts":          timestamp(),
        "version":     "3.1",
        "criticos_ok": True,
        "faltantes_criticos": [],
        "carpetas":    [],
        "resumen":     {"ok": 0, "cambios": 0, "nuevos": 0, "errores": 0, "sin_manifiesto": 0},
    }

    # 1. Archivos críticos
    faltantes_criticos = verificar_criticos()
    if faltantes_criticos:
        reporte["criticos_ok"] = False
        reporte["faltantes_criticos"] = faltantes_criticos
        if not silencioso:
            print(c("rojo", "  ❌ ARCHIVOS CRÍTICOS FALTANTES:"))
            for f in faltantes_criticos:
                print(c("rojo", f"     - {f}"))
            print()
    else:
        if not silencioso:
            print(c("verde", f"  ✅  Archivos críticos: todos presentes ({len(ARCHIVOS_CRITICOS)})"))

    # 2. Verificar cada carpeta
    for carpeta in CARPETAS_VIGILADAS:
        if not carpeta.exists():
            if not silencioso:
                print(c("gris", f"  ⬛  {carpeta.name}/  — carpeta no existe"))
            continue

        res = verificar_carpeta(carpeta)
        reporte["carpetas"].append(res)
        estado = res["estado"]
        reporte["resumen"][estado if estado in reporte["resumen"] else "errores"] += 1

        if not silencioso:
            if estado == "ok":
                archivos_n = len(listar_archivos_carpeta(carpeta))
                print(c("verde", f"  ✅  {carpeta.name}/  — {archivos_n} archivos · sin cambios"))
            elif estado == "cambios":
                print(c("amarillo", f"  ⚠️   {carpeta.name}/  — CAMBIOS DETECTADOS"))
                for f in res["faltantes"]:
                    print(c("rojo",     f"     ❌ Faltante: {f}"))
                for m in res["modificados"]:
                    print(c("amarillo", f"     🔄 Modificado: {m['archivo']}  [{m['sha_anterior']} → {m['sha_actual']}]"))
            elif estado == "nuevos":
                print(c("cyan", f"  🆕  {carpeta.name}/  — {len(res['nuevos'])} archivos nuevos"))
                for n in res["nuevos"]:
                    print(c("cyan", f"     + {n}"))
            elif estado == "sin_manifiesto":
                print(c("gris", f"  ⬜  {carpeta.name}/  — sin manifiesto (ejecuta --init)"))
            else:
                print(c("rojo", f"  ❌  {carpeta.name}/  — {res['errores']}"))

    # 3. Guardar reporte
    REPORTE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(REPORTE_FILE, "w", encoding="utf-8") as f:
        json.dump(reporte, f, indent=2, ensure_ascii=False)

    # 4. Log
    resumen = reporte["resumen"]
    estado_gral = "OK" if resumen["cambios"] == 0 and resumen["errores"] == 0 and reporte["criticos_ok"] else "ALERTA"
    log(f"VERIFICACIÓN {estado_gral}: ok={resumen['ok']} cambios={resumen['cambios']} nuevos={resumen['nuevos']} errores={resumen['errores']} criticos_ok={reporte['criticos_ok']}")

    if not silencioso:
        print()
        if estado_gral == "OK":
            print(c("verde", "  🛡️  MAER en perfecto estado. Sin amenazas detectadas."))
        else:
            print(c("amarillo", "  ⚠️   Se detectaron cambios o errores. Revisa el reporte."))
        print(c("gris", f"\n  Reporte guardado en: {REPORTE_FILE.relative_to(BASE_DIR)}"))
        print()

    return reporte


# ── MODO WATCH ─────────────────────────────────────────────

def modo_watch(intervalo_min: int = 60):
    """Monitoreo continuo. Verifica cada N minutos."""
    print(c("cyan", f"\n🛡️  MAER Guardian — Modo Vigilancia"))
    print(c("gris", f"   Intervalo: {intervalo_min} minutos · Ctrl+C para salir\n"))
    log(f"WATCH START: intervalo={intervalo_min}min")

    while True:
        reporte = verificar_todo(silencioso=True)
        resumen  = reporte["resumen"]
        estado   = "🟢 OK" if resumen["cambios"] == 0 and resumen["errores"] == 0 else "🟡 CAMBIOS"
        print(c("gris", f"  [{timestamp()}] {estado}  cambios={resumen['cambios']}  nuevos={resumen['nuevos']}  errores={resumen['errores']}"))

        if resumen["cambios"] > 0 or resumen["errores"] > 0 or not reporte["criticos_ok"]:
            print(c("amarillo", "  ⚠️  Cambios detectados — ejecuta sin --watch para ver el detalle."))

        try:
            time.sleep(intervalo_min * 60)
        except KeyboardInterrupt:
            print(c("cyan", "\n\n  Vigilancia detenida. Hasta luego."))
            log("WATCH STOP: por el usuario")
            break


# ── REPORTE ─────────────────────────────────────────────────

def mostrar_reporte():
    """Muestra el último reporte guardado."""
    if not REPORTE_FILE.exists():
        print(c("amarillo", "\n  Sin reporte previo. Ejecuta: python maer_guardian.py\n"))
        return
    with open(REPORTE_FILE, encoding="utf-8") as f:
        r = json.load(f)

    print(c("cyan", f"\n🛡️  Último reporte MAER Guardian"))
    print(c("gris", f"   Generado: {r.get('ts','?')}\n"))
    print(f"  Críticos OK:    {c('verde','✅') if r.get('criticos_ok') else c('rojo','❌')}")
    print(f"  Carpetas OK:    {c('verde', str(r['resumen']['ok']))}")
    print(f"  Con cambios:    {c('amarillo' if r['resumen']['cambios'] else 'verde', str(r['resumen']['cambios']))}")
    print(f"  Con errores:    {c('rojo' if r['resumen']['errores'] else 'verde', str(r['resumen']['errores']))}")
    print()

    if r.get("faltantes_criticos"):
        print(c("rojo", "  Críticos faltantes:"))
        for f in r["faltantes_criticos"]:
            print(c("rojo", f"    - {f}"))
    print()


# ── MAIN ─────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="MAER Guardian — Verificador de integridad del sistema MAER",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Ejemplos:
  python maer_guardian.py               # Verificar todo
  python maer_guardian.py --init        # Crear manifiestos (primera vez)
  python maer_guardian.py --reporte     # Ver último reporte
  python maer_guardian.py --watch       # Modo vigilancia (cada 60 min)
  python maer_guardian.py --watch 30    # Modo vigilancia cada 30 min
  python maer_guardian.py --update      # Actualizar manifiestos tras cambios
        """
    )
    parser.add_argument("--init",    action="store_true", help="Crear manifiestos iniciales")
    parser.add_argument("--watch",   nargs="?", const=60, type=int, metavar="MINUTOS",
                        help="Modo vigilancia continua (default: 60 min)")
    parser.add_argument("--reporte", action="store_true", help="Mostrar último reporte guardado")
    parser.add_argument("--update",  action="store_true", help="Actualizar manifiestos con estado actual")
    parser.add_argument("--log",     action="store_true", help="Mostrar últimas entradas del log")

    args = parser.parse_args()

    print(c("bold", c("cyan", "\n  ╔══════════════════════════════════════╗")))
    print(c("bold", c("cyan",   "  ║   🦁  MAER Guardian  v3.1             ║")))
    print(c("bold", c("cyan",   "  ║   Leonel Houssen Mojica — MAER        ║")))
    print(c("bold", c("cyan",   "  ╚══════════════════════════════════════╝")))

    if args.init:
        init_manifiestos()
    elif args.update:
        print(c("cyan", f"\n🔄  Actualizando manifiestos..."))
        init_manifiestos()
    elif args.watch is not None:
        modo_watch(args.watch)
    elif args.reporte:
        mostrar_reporte()
    elif args.log:
        if LOG_FILE.exists():
            lineas = LOG_FILE.read_text(encoding="utf-8").splitlines()
            print(c("cyan", f"\n📋  Últimas {min(30, len(lineas))} entradas del log:\n"))
            for l in lineas[-30:]:
                print(c("gris", f"  {l}"))
            print()
        else:
            print(c("amarillo", "\n  Sin log todavía.\n"))
    else:
        # Verificación por defecto
        verificar_todo(silencioso=False)


if __name__ == "__main__":
    main()
